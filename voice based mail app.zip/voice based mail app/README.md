# Voice_based_email_for_visually_impaired
This project aims at developing an email system that will helps visually impaired person to use the services for communication without previous training.
